<footer class="sticky-footer " style="background-color:rgba(0, 0, 0,1)">

                <div class="container my-auto">
                    <div class="copyright text-center my2 text-light">
                        <p>For any inquiry Message Admin on Whatsapp: +2349039877500</p>
                        <p>Copyright &copy;  Inventures.com.ng 2024</p>
                         
    <a href="https://chat.whatsapp.com/J6SeomEwht28DhEbwjqjBX" class="text-light" style="text-decoration:none">
     
      <i class="fa fa-whatsapp py-2 text-success font-weight-bold" >Join Whatsapp</i> Group
    </a>
   
  </div>
                        
                    </div>
                </div>
               

            </footer>
     
           
     
     <!-- Bootstrap core JavaScript-->
        <script src="../../vendor/jquery/jquery.min.js"></script>
    <script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../../js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="../../vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    
    <script src="../../vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="../../vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="../../js/demo/datatables-demo.js"></script>

    </body>

</html>